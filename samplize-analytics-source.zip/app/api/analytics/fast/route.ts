import { startOfMonth, subYears, format } from "date-fns";
import {
  getCachedRecentOrders,
  setCachedRecentOrders,
} from "@/lib/ordersCache";
import { fetchRecentOrdersViaBulk, type RecentOrder } from "@/lib/bulkOperations";
import { fetchAllOrders, type ShopifyConfig, type ShopifyOrder } from "@/lib/shopify";
import { computeMetricsFromRecentOrders, type StoreMetrics } from "@/lib/analytics";

export const dynamic = "force-dynamic";
export const revalidate = 0;
export const maxDuration = 60;

const MTD_LY_FIELDS =
  "id,created_at,current_total_price,line_items,shipping_address,source_name,financial_status";

function getConfig(): ShopifyConfig | null {
  const url = process.env.SAMPLIZE_STORE_URL;
  const token = process.env.SAMPLIZE_API_KEY;
  if (!url || !token) return null;
  return { storeUrl: url, accessToken: token };
}

function shopifyOrderToRecent(o: ShopifyOrder): RecentOrder {
  const totalPrice = parseFloat(String(o.current_total_price || "0").replace(/[^0-9.-]/g, "")) || 0;
  const lineItems = (o.line_items || []).map((li) => {
    const title = (li.title ?? "Unknown").trim() || "Unknown";
    const qty = li.quantity ?? 0;
    const unitPrice = parseFloat(String(li.price || "0").replace(/[^0-9.-]/g, "")) || 0;
    return {
      title,
      quantity: qty,
      unitPrice,
      productId: null,
      productTitle: title,
      lineRevenue: qty * unitPrice,
    };
  });
  return {
    id: String(o.id),
    createdAt: o.created_at ?? "",
    totalPrice: Number.isFinite(totalPrice) ? totalPrice : 0,
    lineItems,
    shippingCountryCode: (o.shipping_address?.country_code ?? "").toUpperCase(),
    sourceName: (o.source_name ?? "").trim() || "",
    financialStatus: (o.financial_status ?? "").toLowerCase(),
    customerId: null,
    hasRefund: false,
  };
}

async function fetchMtdLyOrdersViaRest(config: ShopifyConfig): Promise<RecentOrder[]> {
  const today = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());
  const monthStartLy = startOfMonth(subYears(today, 1));
  const sameDayLy = subYears(today, 1);
  const min = format(monthStartLy, "yyyy-MM-dd'T'00:00:00'Z'");
  const max = format(sameDayLy, "yyyy-MM-dd'T'23:59:59'Z'");
  console.log("[fast] MTD LY REST date range (UTC)", { created_at_min: min, created_at_max: max });
  const orders = await fetchAllOrders(config, min, max, MTD_LY_FIELDS);
  return orders.map(shopifyOrderToRecent);
}

export async function GET() {
  const config = getConfig();
  if (!config) {
    return Response.json(
      { error: "Missing SAMPLIZE_STORE_URL or SAMPLIZE_API_KEY" },
      { status: 500 }
    );
  }

  const cached = getCachedRecentOrders();
  if (cached) {
    console.log("[fast] cache hit");
    const metrics = computeMetricsFromRecentOrders(
      cached.orders,
      cached.mtdLyOrders,
      "samplize",
      "Samplize",
      new Date()
    );
    return Response.json({
      metrics,
      cachedAt: cached.cachedAt,
    });
  }

  console.log("[fast] cache miss - running bulk op and REST MTD LY");
  const [recentOrders, mtdLyOrders] = await Promise.all([
    fetchRecentOrdersViaBulk(),
    fetchMtdLyOrdersViaRest(config),
  ]);
  console.log("[fast] bulk op complete", recentOrders.length, "orders fetched");
  console.log("[fast] MTD LY REST complete", mtdLyOrders.length, "orders fetched");

  setCachedRecentOrders(recentOrders, mtdLyOrders.length > 0 ? mtdLyOrders : null);

  const metrics: StoreMetrics = computeMetricsFromRecentOrders(
    recentOrders,
    mtdLyOrders.length > 0 ? mtdLyOrders : null,
    "samplize",
    "Samplize",
    new Date()
  );
  return Response.json({
    metrics,
    cachedAt: new Date().toISOString(),
  });
}
