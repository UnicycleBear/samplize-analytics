import { clearOrdersCache } from "@/lib/ordersCache";
import { refreshWeeklyCache } from "@/lib/weeklyCache";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function POST() {
  clearOrdersCache();
  const payload = await refreshWeeklyCache();
  return Response.json({
    success: true,
    updatedAt: payload.cachedAt,
  });
}
